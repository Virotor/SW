﻿#include <iostream>
#include <math.h>
#include <string>
#include <ctime>
#include <vector>
using namespace std;

long long seed;

void task1()
{
    cout << "task 1 - Rectangle\n";
    int x, y, P, S;
    cout << "Enter length\n"; cin >> x;
    cout << "Enter height\n"; cin >> y;
    P = (x + y) * 2;
    S = x * y;
    cout << "P =" << P << endl << "S =" << S << endl;
    for (int i = 1; i <= y; i++)
    {
        for (int j = 1; j <= x; j++)
        {
            cout << "*";
        }
        cout << endl;
    }
    cout << "task 1 completed\n\n";
}

void task2()
{
    cout << "task 2 - Fibonacci numbers\n";
    int num1,num2,n;
    num1 = 0; num2 = 1;
    cout << "Enter n\n"; cin >> n; cout << num1 << " ";
    for (int i = 1; i < n; i++)
    {
        cout << num2 << " ";
        num2 += num1;
        num1 = num2 - num1;
    }
    cout << "\ntask 2 completed\n\n";
}
int prime(int num)
{
    for (int i = 2; i < sqrt(num); i++)
    {
        if (num % i == 0)
        {
            cout << num << " is not prime\n";
            return 1;
        }           
    }
    cout << num << " is prime\n";
    return 0;
}
int gcd(int num1, int num2) 
{
    for (int i = num1; i > 0; i--)
    {
        if (num1 % i == 0 && num2 % i == 0)
        {
            cout << "gcd = " << i<<endl;
            return 0;
        }
    }
    return 0;
}
/* по факту оно работает только с положительными числами и только если ни одно из чисел не равно нулю.
и  чтобы поправить это надо бы брать модули числа + смотреть какое из них максимальное чтобы если одно из чисел равно нулю все считало нормально  но типо уже поздно*/

void task3()
{
    cout << "task 3 - Prime numbers\n";
    int num1,num2;
    cout << "Enter number 1\n"; cin >> num1;
    cout << "Enter number 2\n"; cin >> num2;
    prime(num1);
    prime(num2);
    gcd(num1, num2);
    cout << "task 3 completed\n\n";
}

void task4()
{
    cout << "Task 4 - Binary number\n";
    int num;
    string bin = " ";
    cout << "Enter number\n"; cin >> num;
    while (num >= 1)
    {
        bin += to_string(num % 2);
        num = num / 2;
    }
    reverse(bin.begin(), bin.end());
    cout<<bin << "\ntask 4 completed\n\n";
}

int random()
{
    int a, m;
    a = 16807; m = 0x7fffffff;
    seed = seed * a % m;
    return seed;
}

void task5()
{
    cout << "task 5 - Random\n";
    vector<int> arr(10,0);
    seed = time(nullptr);
    for (int i = 0; i < 22000000; i++)
    {
        arr[random() % 10]++;
    }
    for (int number : arr)
        cout << number << endl;
    for (int number : arr)
    {     
        number = number / 22000;
        for (int i = 0; i < number; i++)
            cout << "*";
        cout << endl << endl;
    }
    cout << "task 5 completed\n\n";
}

int main()
{
    task1();
    task2();
    task3();
    task4();
    task5();
    system("pause");
    return 0;
}


