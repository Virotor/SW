#include <math.h>
#include <iostream>

using namespace std;

int main()
{
    int task;
    setlocale(LC_ALL, "Russian");
    cout << "Введите номер задания (1 - месяца, 2 - трехзначное число)\n";
    cin >> task;

    switch (task)
    {
    case 1:
    {
        int month;
        cout << "Введите номер месяца\n"; cin >> month;
        switch (month)
        {
        case 1:
        {
            cout << "Январь\n"; cout << "Зима\n";
            break;
        }
        case 2:
        {
            cout << "Февраль\n"; cout << "Зима\n";
            break;
        }
        case 3:
        {
            cout << "Март\n"; cout << "Весна\n";
            break;
        }
        case 4:
        {
            cout << "Апрель\n"; cout << "Весна\n";
            break;
        }
        case 5:
        {
            cout << "Май\n"; cout << "Весна\n";
            break;
        }
        case 6:
        {
            cout << "Июнь\n"; cout << "Лето\n";
            break;
        }
        case 7:
        {
            cout << "Июль\n"; cout << "Лето\n";
            break;
        }
        case 8:
        {
            cout << "Август\n"; cout << "Лето\n";
            break;
        }
        case 9:
        {
            cout << "Сентябрь\n"; cout << "Осень\n";
            break;
        }
        case 10:
        {
            cout << "Октябрь\n"; cout << "Осень\n";
            break;
        }
        case 11:
        {
            cout << "Ноябрь\n"; cout << "Осень\n";
            break;

        }
        case 12:
        {
            cout << "Декабрь\n"; cout << "Зима\n";
            break;
        }
        default:
            cout << "Неверно введен месяц";
            break;
        }
        break;
    }
    case 2:
    {

        int number, a, b, c;
        cout << "Введите трехзначное число\n"; cin >> number;
        if (number % 2 == 1)
        {
            cout << "Число нечетное\n";
        }
        else
        {
            cout << "Число четное\n";
        }
        double sum;
        a = number / 100;
        b = number / 10 - a * 10;
        c = number % 10;
        sum = (a + b + c) / 3.;
        cout << sum << endl;
        break;
    }
    default:
        cout << "Неверно введен номер задания";
        break;
    }

}
